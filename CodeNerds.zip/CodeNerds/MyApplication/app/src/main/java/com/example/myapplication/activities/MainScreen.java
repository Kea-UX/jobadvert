package com.example.myapplication.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


import com.example.myapplication.ApplicationClass;
import com.example.myapplication.R;

/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */


public class MainScreen extends AppCompatActivity {
    TextView tvMail;
    String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Welcome Screen");

        tvMail=findViewById(R.id.tvMail);
        userEmail = getIntent().getStringExtra("userEmail");
        tvMail.setText("Welcome\n"+userEmail);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        userEmail = getIntent().getStringExtra("userEmail");
        switch (item.getItemId())
        {
            case R.id.save:
                int flag = 10;
                userLoggedIn();
                ApplicationClass.showToast(getLayoutInflater(), MainScreen.this, flag, userEmail);
                startActivity(new Intent(MainScreen.this, LoginActivity.class));
                MainScreen.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void userLoggedIn()
    {
        SharedPreferences preferences = getSharedPreferences("userLoggedIn", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("rememberMe", "False");
        editor.apply();
    }
}