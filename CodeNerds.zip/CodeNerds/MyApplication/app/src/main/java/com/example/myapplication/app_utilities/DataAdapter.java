package com.example.myapplication.app_utilities;

public class DataAdapter {
}
