package com.example.myapplication.app_utilities;

public interface CardViewButtonClickListener {
    void onEditAdvertClick();
    void onViewAdvertClick();
    void onDeleteAdvertClick();
    void onJobApplicationClick();
}
