package com.example.myapplication.db_reporities.job_application;

public class GetUserApplicationsAsync {
}
