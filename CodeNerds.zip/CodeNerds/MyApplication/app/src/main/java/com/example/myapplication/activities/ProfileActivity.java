package com.example.myapplication.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.ApplicationClass;
import com.example.myapplication.R;
import com.example.myapplication.data_models.User;
import com.example.myapplication.db_reporities.AsyncTaskCallback;
import com.example.myapplication.db_operations.SaveNewEntryToDB;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */
public class ProfileActivity extends AppCompatActivity {
    TextInputLayout txtInputEmail,txtInputPrimaryPassword,txtInputSecondaryPassword;
    Button btnRegister;
    int flag = 0;
    ArrayList<User> users;

    public ArrayList<User> getUsers() {
        return users;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);
        txtInputEmail= findViewById(R.id.txtInputEmail);
        txtInputPrimaryPassword = findViewById(R.id.txtInputPrimaryPassword);
        txtInputSecondaryPassword = findViewById(R.id.txtInputSecondaryPassword);

        btnRegister = findViewById(R.id.btnRegister);
        final LayoutInflater inflater = getLayoutInflater();

        users = new ArrayList<User>();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String email = txtInputEmail.getEditText().getText().toString().trim();
                String primarypassword = txtInputPrimaryPassword.getEditText().getText().toString().trim();
                String secondpassword = txtInputSecondaryPassword.getEditText().getText().toString().trim();

                User user = new User(email,primarypassword);
                ApplicationClass.users.add(user);

                if (email.isEmpty()||primarypassword.isEmpty()||secondpassword.isEmpty())
                {
                   flag=1;
                   ApplicationClass.showToast(inflater, ProfileActivity.this, flag, email);
                }
                else if(primarypassword.length()<6 || secondpassword.length()<6)
                {
                    flag=2;
                    ApplicationClass.showToast(inflater, ProfileActivity.this, flag, email);
                }
                else if(!primarypassword.matches(secondpassword))
                {
                    flag=3;
                    ApplicationClass.showToast(inflater, ProfileActivity.this, flag, email);
                }
                else
                {
                    flag=4;

                    ApplicationClass.showToast(inflater, ProfileActivity.this, flag, email);
                    new SaveNewEntryToDB(user, ProfileActivity.this, new AsyncTaskCallback<User>() {
                        @Override
                        public void handleResponse(User object) {
                            ApplicationClass.showToast(inflater, ProfileActivity.this, flag,email);
                            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
                            startActivity(intent);
                        }

                        @Override
                        public void handleFault(Exception e) {
                            flag = 5;
                            ApplicationClass.showToast(inflater, ProfileActivity.this, flag, e.getMessage());
                        }
                    }).execute();
                }
            }
        });
    }
}