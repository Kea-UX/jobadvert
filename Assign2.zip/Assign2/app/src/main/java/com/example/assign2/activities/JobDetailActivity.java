package com.example.assign2.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.assign2.R;

public class JobDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_detail);
    }
}