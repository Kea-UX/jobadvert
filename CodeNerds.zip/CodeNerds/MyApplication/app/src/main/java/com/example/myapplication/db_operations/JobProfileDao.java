package com.example.myapplication.db_operations;

import com.example.myapplication.data_models.JobProfile;

import java.util.List;

public interface JobProfileDao {
    void delete(long id);
    List<JobProfile> getAllJobProfiles();
    JobProfile getJobProfileById(long id);
    JobProfile getJobProfileByEmail(String email);
}
