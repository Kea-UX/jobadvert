package com.example.myapplication.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.example.myapplication.ApplicationClass;
import com.example.myapplication.R;
import com.example.myapplication.data_models.User;
import com.example.myapplication.db_reporities.AsyncTaskCallback;
import com.example.myapplication.db_operations.GetDataFromDB;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */

public class LoginActivity extends AppCompatActivity {
    private static final String FILE = "kops.txt";
    TextInputLayout textilPassword,textilEmail;
    CheckBox cbLogin;
    AutoCompleteTextView autoEmail, autoPassword;
    Button btnLogin, btnReg;
    int flag =0;
    User user;
    ArrayList<String> userEmails;
    ArrayList<User> users;
    boolean authoriseUser = false;
    static String loginEmail ="", loginPassword = "";
    CardView cvLogin,cvReg;

    boolean resultsEmail =false,resultsPass=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        autoEmail = findViewById(R.id.autoMail);
        autoPassword = findViewById(R.id.autoPassword);
        cbLogin = findViewById(R.id.cbLogin);
        textilEmail = findViewById(R.id.textilEmail);
        textilPassword = findViewById(R.id.textilPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnReg = findViewById(R.id.btnReg);

        users = new ArrayList<>();

        loadUsers();
        userEmails = new ArrayList<>();
        users = new ArrayList<User>();

        final LayoutInflater inflater = getLayoutInflater();
        SharedPreferences preferences = getSharedPreferences("userLoggedIn", MODE_PRIVATE);
        String check = preferences.getString("rememberMe", "");
        userLoggedIn(check,inflater);

        cbLogin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(compoundButton.isChecked())
                {
                    SharedPreferences preferences = getSharedPreferences("userLoggedIn", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("rememberMe", "True");
                    Toast.makeText(LoginActivity.this, "Keep me logged in.", Toast.LENGTH_SHORT).show();
                    editor.apply();
                }
                else
                {
                    SharedPreferences preferences = getSharedPreferences("userLoggedIn", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("rememberMe", "False");
                    Toast.makeText(LoginActivity.this, "Don't keep me logged in.", Toast.LENGTH_SHORT).show();
                    editor.apply();
                }
            }
        });

        btnReg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

            String logMail = textilEmail.getEditText().getText().toString().trim();
            String logPassword = textilPassword.getEditText().getText().toString().trim();
            user = new User(logMail,logPassword);
            ApplicationClass.users.add(user);

            if(logMail.isEmpty() || logPassword.isEmpty())
            {
                flag = 1;
                ApplicationClass.showToast(inflater, LoginActivity.this, flag, logMail);
            }
            else
            {
                user = new User(logMail, logPassword);
                loginEmail = user.getEmail();
                loginPassword = user.getPassword();

                for(int i = 0; i < users.size() && authoriseUser == false; i++)
                {
                    authoriseUser = users.get(i).getEmail().equals(user.getEmail()) && users.get(i).getPassword().equals(user.getPassword());
                }

                if(authoriseUser)
                {
                    flag = 6;
                    ApplicationClass.showToast(inflater, LoginActivity.this, flag, logMail);
                    Intent intent = new Intent(LoginActivity.this, MainScreen.class);
                    intent.putExtra("userEmail", user.getEmail());
                    startActivity(intent);
                    LoginActivity.this.finish();
                }
                else
                {
                    flag = 7;
                    ApplicationClass.showToast(inflater, LoginActivity.this, flag, logMail);
                }
            }
        }
        });
}
    //Loading users from file.
    private void loadUsers()
    {
        new GetDataFromDB(LoginActivity.this, new AsyncTaskCallback<ArrayList<User>>() {
            @Override
            public void handleResponse(ArrayList<User> array) {

                if(array != null)
                {
                    for (int i = 0; i< array.size(); i++)
                    {
                        users.add(array.get(i));
                        userEmails.add(array.get(i).getEmail());
                        autoCompleteUsers();
                    }
                }
            }

            @Override
            public void handleFault(Exception e) {
                flag = 5;
               ApplicationClass.showToast(getLayoutInflater(), LoginActivity.this, flag, e.getMessage());
            }
        }).execute();
    }


    private void userLoggedIn(String check, LayoutInflater inflater)
    {
        if(check.equals("True"))
        {
            flag = 6;
            ApplicationClass.showToast(inflater, LoginActivity.this, flag, null);
            startActivity(new Intent(LoginActivity.this, MainScreen.class));
            LoginActivity.this.finish();
        }
    }

    private void autoCompleteUsers()
    {
        if(userEmails != null){
            ArrayAdapter<String> adapter = new ArrayAdapter<>(LoginActivity.this, android.R.layout.select_dialog_item, userEmails);

            autoEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View view, boolean b) {
                    if(b)
                    {
                        autoEmail.showDropDown();
                        for(int i = 0; i < users.size(); i++)
                        {
                            autoEmail.setText(loginEmail);
                            autoPassword.setText(loginPassword);
                        }
                    }
                }
            });
            autoEmail.setAdapter(adapter);
        }
    }
}