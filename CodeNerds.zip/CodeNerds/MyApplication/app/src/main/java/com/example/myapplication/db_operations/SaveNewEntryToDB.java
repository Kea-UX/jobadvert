package com.example.myapplication.db_operations;

import android.content.Context;
import android.os.AsyncTask;
import com.example.myapplication.ApplicationClass;
import com.example.myapplication.data_models.User;
import com.example.myapplication.db_reporities.AsyncTaskCallback;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;
/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */
public class SaveNewEntryToDB extends AsyncTask<Integer, Void, User>
{
    private static final String FILE = "kops.txt";
    private Exception exception;
    private User user;
    private Context context;
    private AsyncTaskCallback callback;
    ArrayList<User> users = new ArrayList<User>();

    public SaveNewEntryToDB(User user, Context context, AsyncTaskCallback<User> callback)
    {
        this.user = user;
        this.context = context;
        this.callback = callback;
    }

    @Override
    protected User doInBackground(Integer... integers) {

        FileOutputStream file;

        try {
            file = this.context.openFileOutput(FILE, MODE_PRIVATE);
            OutputStreamWriter outputFile = new OutputStreamWriter(file);

            for(int i = 0; i < ApplicationClass.users.size(); i++)
            {
                outputFile.write(ApplicationClass.users.get(i).getEmail() + ";" + ApplicationClass.users.get(i).getPassword() + "\n");
            }
            outputFile.flush();
            outputFile.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return this.user;
    }

    @Override
    protected void onPostExecute(User user) {
        if(callback != null)
        {
            if(exception == null)
            {
                callback.handleResponse(user);
            }
            else
            {
                callback.handleFault(exception);
            }
        }
    }

}
