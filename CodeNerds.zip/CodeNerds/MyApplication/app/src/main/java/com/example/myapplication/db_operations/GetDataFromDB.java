package com.example.myapplication.db_operations;

import android.content.Context;
import android.os.AsyncTask;

import com.example.myapplication.ApplicationClass;
import com.example.myapplication.data_models.User;

import java.io.File;
import java.util.ArrayList;

import android.widget.Toast;

import com.example.myapplication.db_reporities.AsyncTaskCallback;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */
public class GetDataFromDB extends AsyncTask<Void, Void, ArrayList<User>>
{
    private static final String FILE = "kops.txt";
    private Exception exception;
    private User user;
    private Context context;
    private AsyncTaskCallback callback;
    //ArrayList<User> users = new ArrayList<User>();

    public GetDataFromDB(Context context, AsyncTaskCallback<ArrayList<User>> callback)
    {
        this.context = context;
        this.callback = callback;
    }

    @Override
    protected ArrayList<User> doInBackground(Void... voids) {
        String lineFromFile = "";
        exception = null;
        ApplicationClass.users.clear();

        if(loadData())
        {
            try {
                BufferedReader bf = new BufferedReader(new InputStreamReader(this.context.openFileInput(FILE)));

                while ((lineFromFile = bf.readLine())!= null)
                {
                    StringTokenizer tokenizer = new StringTokenizer(lineFromFile,";");
                    User user = new User(tokenizer.nextToken(),tokenizer.nextToken());
                    ApplicationClass.users.add(user);
                }

                bf.close();
            }
            catch (IOException io)
            {
                Toast.makeText(context, io.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
           // Toast.makeText(context, "File doesn't exist", Toast.LENGTH_SHORT).show();
        }

        return ApplicationClass.users;
    }

    @Override
    protected void onPostExecute(ArrayList<User> users) {
        super.onPostExecute(users);

        if(callback != null)
        {
            if(exception == null)
            {
                callback.handleResponse(users);
            }
            else
            {
                callback.handleFault(exception);
            }
        }
    }

    public boolean loadData()
    {
        boolean loadFile = false;
        File textFile = this.context.getApplicationContext().getFileStreamPath(FILE);
        if(textFile.exists())
        {
            loadFile = true;
        }
        return loadFile;
    }

}
