package com.example.myapplication.db_operations;

import com.example.myapplication.data_models.JobAdvert;
import com.example.myapplication.data_models.JobApplication;

import java.util.List;

public interface JobApplicationDao {
    List<JobApplication> getAllJobApplications();
    List<JobApplication> getUserApplications(long profileId);
    void delete(long jobId, long applicantId);
    JobApplication findByJobIdAndUserId(long jobId, long profileId);
    List<JobAdvert> getUserAppliedJobAdverts(long profileId);
}
