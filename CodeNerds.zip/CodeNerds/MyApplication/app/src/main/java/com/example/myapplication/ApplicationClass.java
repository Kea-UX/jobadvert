package com.example.myapplication;

import android.app.Application;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.data_models.User;

import java.util.ArrayList;
/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */
public class ApplicationClass extends Application
{
    public static ArrayList<User> users;

    @Override
    public void onCreate() {
        super.onCreate();

        users = new ArrayList<User>();
    }

    public static void showToast(LayoutInflater inflater, Context context, int num, String email)
    {
        View toastView;

        toastView = inflater.inflate(R.layout.toast_layout, (ViewGroup) ((AppCompatActivity) context).findViewById(R.id.toaster));
        Toast toast = new Toast(context);
        TextView toast_text = toastView.findViewById(R.id.toast_text);
        ImageView toast_img = toastView.findViewById(R.id.toast_img);

        switch (num)
        {
            case 1:
                toast_text.setText("\tEnter all fields");
                toast_img.setImageResource(R.drawable.incorrect_toast);
                break;
            case 2:
                toast_text.setText("\tPlease make sure the password is at least 6 characters!");
                toast_img.setImageResource(R.drawable.incorrect_toast);
                break;

            case 3:
                toast_text.setText("\tPlease make sure that passwords match!");
                toast_img.setImageResource(R.drawable.incorrect_toast);
                break;
            case 4:

                toast_text.setText("\t"+email+" successfully registered");
                toast_img.setImageResource(R.drawable.correct_toast);
                break;
            case 5:
                    toast_text.setText("\tError: "+email);
                    toast_img.setImageResource(R.drawable.incorrect_toast);
                    break;
            case 6:
                toast_text.setText("\tSuccessfully authenticated");
                toast_img.setImageResource(R.drawable.correct_toast);

                break;
            case 7:
                toast_text.setText("\tIncorrect password provided or user doesn't exist!");
                toast_img.setImageResource(R.drawable.incorrect_toast);
                break;

            case 9:
                toast_text.setText("\tSuccessfully logged out");
                toast_img.setImageResource(R.drawable.correct_toast);
                break;

            case 10:
            toast_text.setText("\tLogging out!");
            toast_img.setImageResource(R.drawable.correct_toast);
            break;
        }

        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastView);
        toast.setGravity(Gravity.BOTTOM|Gravity.FILL_HORIZONTAL, 0, 0);
        toast.show();
    }

}
