package com.example.assign2.db_operations;

public interface JobAdvertDao {
}
