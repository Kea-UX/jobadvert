package com.example.myapplication.db_reporities;
import com.example.myapplication.data_models.User;
/* Student Number : initials Surname
 * 217011965 KM Mabaso
 * 217011971 K Mathang
 * 217011931 NM Meko
 * 218013839 MP Tselane
 */
public interface AsyncTaskCallback <T>{
    void onSuccess(T object);
    void handleFault(Exception e);
}
