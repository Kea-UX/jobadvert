package com.example.assign2.db_reporitories;

public interface AsyncTaskCallback {
}
