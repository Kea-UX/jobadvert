package com.example.myapplication.db_operations;

public interface GenericDao<T> {
    void insert(T tInsert);
    void delete(T tDelete);
    void update(T tUpdate);
}
