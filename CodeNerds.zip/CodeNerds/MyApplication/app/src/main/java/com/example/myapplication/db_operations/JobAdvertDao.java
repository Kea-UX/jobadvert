package com.example.myapplication.db_operations;

import com.example.myapplication.data_models.JobAdvert;

import java.util.List;

public interface JobAdvertDao {
    void delete(long id);
    List<JobAdvert> getAllJobAdverts();
    JobAdvert getJobAdvertById(long id);
}
