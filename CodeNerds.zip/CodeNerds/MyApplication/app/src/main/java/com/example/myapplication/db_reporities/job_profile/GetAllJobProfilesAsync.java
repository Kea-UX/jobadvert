package com.example.myapplication.db_reporities.job_profile;

public class GetAllJobProfilesAsync {
}
