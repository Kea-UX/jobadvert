package com.example.assign2.data_models;

public class JobProfile {
}
